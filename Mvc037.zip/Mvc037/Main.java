import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("User Selection");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(300, 200);

            // Calculate the coordinates to center the frame on the screen
            int screenWidth = Toolkit.getDefaultToolkit().getScreenSize().width;
            int screenHeight = Toolkit.getDefaultToolkit().getScreenSize().height;
            int frameWidth = frame.getSize().width;
            int frameHeight = frame.getSize().height;
            int xCoordinate = (screenWidth - frameWidth) / 2;
            int yCoordinate = (screenHeight - frameHeight) / 2;

            // Set the frame's coordinates to center it on the screen
            frame.setLocation(xCoordinate, yCoordinate);

            // Set the layout manager to GridBagLayout for more control
            frame.setLayout(new GridBagLayout());

            GridBagConstraints gbc = new GridBagConstraints();
            gbc.fill = GridBagConstraints.HORIZONTAL;
            gbc.insets = new Insets(10, 10, 10, 10);

            JButton commandLineButton = new JButton("Collegian");
            JButton guiButton = new JButton("Adolescent");
          
            JButton largeGuiButton = new JButton("Elderly");

            UserView userView = new UserView();

            commandLineButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    frame.dispose();
                    userView.runCommandLineInterface();
                }
            });

            guiButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    frame.dispose();
                    userView.runGUIInterface();
                }
            });

            largeGuiButton.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    frame.dispose();
                    userView.runLargeGUIInterface();
                }
            });

            // Add buttons to the frame using GridBagConstraints
            gbc.gridx = 0;
            gbc.gridy = 0;
            frame.add(commandLineButton, gbc);

            gbc.gridy = 1;
            frame.add(guiButton, gbc);

            gbc.gridy = 2;
            frame.add(largeGuiButton, gbc);

            frame.setVisible(true);
        });
    }
}
