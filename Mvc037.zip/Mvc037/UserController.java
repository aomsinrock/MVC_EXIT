import java.util.HashMap;
import java.util.Map;

class UserController {
    private Map<String, String> credentials;

    public UserController() {
        credentials = new HashMap<>();
        // Initialize with some default username-password pairs
        credentials.put("user1", "password1");
        credentials.put("usera2", "password2d");
        credentials.put("users2", "password2a");
        credentials.put("userd2", "password2d");
        credentials.put("user2a", "password2dd");

    }

    public boolean authenticate(String username, String password) {
        return credentials.containsKey(username) && credentials.get(username).equals(password);
    }
}
