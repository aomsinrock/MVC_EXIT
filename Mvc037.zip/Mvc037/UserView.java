import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Scanner;

public class UserView {
    private UserController controller;

    public UserView() {
        controller = new UserController();
    }

    public void runCommandLineInterface() {
        Scanner sc = new Scanner(System.in);

        System.out.println("Welcome to the Conference Program (Command-Line Interface)");
        System.out.println("--------------------------------");

        boolean loginSuccess = false;

        while (!loginSuccess) {
            System.out.print("Enter username: ");
            String username = sc.nextLine();
            System.out.print("Enter password: ");
            String password = sc.nextLine();
            System.out.println("--------------------------------");

            loginSuccess = controller.authenticate(username, password);

            if (loginSuccess) {
                System.out.println("Login successful!");
                System.out.print("Do you want to try again? (yes/no): ");
                String tryAgain = sc.nextLine();
                if (!tryAgain.equalsIgnoreCase("yes")) {
                    System.out.println("Goodbye!");
                    break;
                }
            } else {
                System.out.println("Invalid username or password.");
                System.out.print("Do you want to try again? (yes/no): ");
                String tryAgain = sc.nextLine();
                if (!tryAgain.equalsIgnoreCase("yes")) {
                    System.out.println("Goodbye!");
                    break;
                }
            }
        }

        sc.close();
    }

    public void runGUIInterface() {
        JFrame frame = new JFrame("Login");
        ImageIcon img = new ImageIcon("logo.png");
        frame.setIconImage(img.getImage());
        frame.setSize(300, 200);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());

        JTextField usernameField = new JTextField(20);
        JPasswordField passwordField = new JPasswordField(20);
        JButton loginButton = new JButton("Login");

        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());

                if (controller.authenticate(username, password)) {
                    displayLoginSuccess();
                } else {
                    displayLoginFailure(frame);
                }
            }
        });

        frame.add(new JLabel("Username: "));
        frame.add(usernameField);
        frame.add(new JLabel("Password: "));
        frame.add(passwordField);
        frame.add(loginButton);

        // Calculate the x-coordinate to center the frame horizontally
        int screenWidth = Toolkit.getDefaultToolkit().getScreenSize().width;
        int frameWidth = frame.getSize().width;
        int xCoordinate = (screenWidth - frameWidth) / 2;

        // Set the window's x-coordinate to center it horizontally
        frame.setLocation(xCoordinate, frame.getY());

        // Center the frame on the screen vertically
        frame.setLocationRelativeTo(null);

        frame.setVisible(true);
    }

    public void runLargeGUIInterface() {
        JFrame frame = new JFrame("Login (Large)");
        ImageIcon img = new ImageIcon("logo.png");
        frame.setIconImage(img.getImage());
        frame.setSize(800, 600); // Double the size
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());

        JTextField usernameField = new JTextField(40); // Double the size
        JPasswordField passwordField = new JPasswordField(40); // Double the size
        JButton loginButton = new JButton("Login");

        Font font = new Font("Arial", Font.PLAIN, 20);
        usernameField.setFont(font);
        passwordField.setFont(font);
        loginButton.setFont(font);

        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());

                if (controller.authenticate(username, password)) {
                    displayLoginSuccess();
                } else {
                    displayLoginFailure(frame);
                }
            }
        });

        JLabel usernameLabel = new JLabel("Username: ");
        usernameLabel.setFont(font);
        frame.add(usernameLabel);
        frame.add(usernameField);

        JLabel passwordLabel = new JLabel("Password: ");
        passwordLabel.setFont(font);
        frame.add(passwordLabel);
        frame.add(passwordField);

        frame.add(loginButton);

        int screenWidth = Toolkit.getDefaultToolkit().getScreenSize().width;
        int screenHeight = Toolkit.getDefaultToolkit().getScreenSize().height;
        int frameWidth = frame.getSize().width;
        int frameHeight = frame.getSize().height;
        int xCoordinate = (screenWidth - frameWidth) / 2;
        int yCoordinate = (screenHeight - frameHeight) / 2;

        frame.setLocation(xCoordinate, yCoordinate);

        frame.setVisible(true);
    }

    public void displayLoginSuccess() {
        JOptionPane.showMessageDialog(null, "Login successful!");
    }

    public void displayLoginFailure(JFrame frame) {
        JOptionPane.showMessageDialog(frame, "Invalid username or password. Please try again.", "Login Failed", JOptionPane.ERROR_MESSAGE);
    }
}